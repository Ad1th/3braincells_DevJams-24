// server.js

const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch'); // Ensure you have node-fetch installed
const app = express();
const port = 3000;

app.use(cors()); // Allow all origins, methods, and headers
app.use(express.json()); // Middleware to parse JSON bodies

// In-memory storage for saved prompts
let savedPrompts = [];

// Endpoint to get saved prompts
app.get('/prompts', (req, res) => {
  res.json({ savedPrompts });
});

// Endpoint to save a new prompt
app.post('/prompts', (req, res) => {
  const { prompt } = req.body;
  if (prompt) {
    savedPrompts.push(prompt);
    res.json({ message: 'Prompt saved.', savedPrompts });
  } else {
    res.status(400).json({ message: 'Prompt is required.' });
  }
});

// Endpoint to fetch response from Gemini API
app.post('/gemini', async (req, res) => {
  const { prompt } = req.body;
  const geminiApiKey = 'AIzaSyB_Q7STnMR74cWMyWg3hb8VDGt8UWsmJKc'; // Replace with your Gemini API key

  try {
    const response = await fetch('https://generativelanguage.googleapis.com', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${geminiApiKey}`,
      },
      body: JSON.stringify({
        model: 'gemini-1.5-flash',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 150,
      }),
    });

    const data = await response.json();
    if (data.choices && data.choices.length > 0) {
      res.json({ response: data.choices[0].message.content });
    } else {
      res.json({ response: 'No response received.' });
    }
  } catch (error) {
    console.error('Error fetching response:', error);
    res.status(500).json({ message: 'Error fetching response.', error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
