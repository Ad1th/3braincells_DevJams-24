// server.js

const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch'); // Ensure you have node-fetch installed
const app = express();
const port = 3000;

app.use(cors()); // Allow all origins, methods, and headers
app.use(express.json()); // Middleware to parse JSON bodies

// In-memory storage for saved prompts
let savedPrompts = [];

// Endpoint to get saved prompts
app.get('/prompts', (req, res) => {
  res.json({ savedPrompts });
});

// Endpoint to save a new prompt
app.post('/prompts', (req, res) => {
  const { prompt } = req.body;
  if (prompt) {
    savedPrompts.push(prompt);
    res.json({ message: 'Prompt saved.', savedPrompts });
  } else {
    res.status(400).json({ message: 'Prompt is required.' });
  }
});

// Endpoint to fetch response from Gemini API
app.post('/gemini', async (req, res) => {
  const { prompt } = req.body;
  const geminiApiKey = 'AIzaSyB_Q7STnMR74cWMyWg3hb8VDGt8UWsmJKc'; // Replace with your Gemini API key

  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyB_Q7STnMR74cWMyWg3hb8VDGt8UWsmJKc', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt, // Use the user input prompt here
              },
            ],
          },
        ],
      }),
    });
  
    const data = await response.json();
    console.log(data.candidates[0].content.parts[0].text)
    res.json({ message: data.candidates[0].content.parts[0].text });
    // Handle the response correctly based on the structure returned by Gemini API
    
  } catch (error) {
    console.error("Error fetching response:", error);
    console.error("Error message:", error.message); // Logs the error message
    console.error("Error stack:", error.stack); // Logs the stack trace
  }
  
  
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
