document.addEventListener('DOMContentLoaded', function () {
  const sendPromptBtn = document.getElementById('sendPromptBtn');
  const promptInput = document.getElementById('promptInput');
  const responseDiv = document.getElementById('response');

  sendPromptBtn.addEventListener('click', function () {
    const prompt = promptInput.value;

    // Send the prompt to the server
    fetch('http://localhost:3001/gemini', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt }),
    })
      .then((response) => response.json())
      .then((data) => {
        // Display the response in the popup
        responseDiv.innerText = data.message;

        // If there are links, append them to the response
        if (data.links && data.links.length > 0) {
          data.links.forEach((link) => {
            const a = document.createElement('a');
            a.href = link;
            a.textContent = link;
            a.target = '_blank'; // Open links in a new tab
            responseDiv.appendChild(document.createElement('br'));
            responseDiv.appendChild(a);
          });
        }
      })
      .catch((error) => {
        responseDiv.innerText = 'Error: ' + error.message;
      });
  });
});
