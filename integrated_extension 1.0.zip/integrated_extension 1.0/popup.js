document.addEventListener("DOMContentLoaded", () => {
    // Example user data for the pie chart
    fetch('http://localhost:3004/analytics')  // Update to your server's analytics endpoint
        .then(response => response.json())
        .then(data => {
            const userAnalyticsData = {
                labels: ['Prompts Submitted', 'Successful Responses', 'Errors'],
                datasets: [{
                    label: 'User Analytics',
                    data: [data.submitted, data.successful, data.errors],  // Use real data
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
                }]
            };

            const ctx = document.getElementById('userAnalyticsChart').getContext('2d');
            new Chart(ctx, {
                type: 'pie',
                data: userAnalyticsData,
            });
        })
        .catch(error => console.error('Error fetching analytics:', error));

    // Prompt Submission Logic
    document.getElementById("sendPromptBtn").addEventListener("click", async () => {
        const prompt = document.getElementById("promptInput").value;

        try {
            const response = await fetch('http://localhost:3004/gemini', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ prompt })
            });

            const data = await response.json();
            const responseElement = document.getElementById("response");

            if (data.links && data.links.length > 0) {
                responseElement.innerHTML = `Top 3 links:<br>${data.links.map(link => `<a href="${link}" target="_blank">${link}</a>`).join('<br>')}`;
            } else {
                responseElement.textContent = "No links found.";
            }
        } catch (error) {
            console.error('Error fetching response:', error);
            document.getElementById("response").textContent = "Error fetching response. Please try again.";
        }
    });
});
