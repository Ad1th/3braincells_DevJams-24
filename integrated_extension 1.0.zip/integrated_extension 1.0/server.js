const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const app = express();
const port = 3004;

app.use(cors());
app.use(express.json());

// In-memory storage for analytics
let analytics = {
    submitted: 0,
    successful: 0,
    errors: 0
};

// Endpoint to fetch analytics
app.get('/analytics', (req, res) => {
    res.json(analytics);
});

// Endpoint to handle Gemini API prompt and fetch 3 website links
app.post('/gemini', async (req, res) => {
    const { prompt } = req.body;
    const geminiApiKey = 'YOUR_GEMINI_API_KEY';  // Replace with your actual Gemini API key

    try {
        // Construct the enhanced prompt
        const enhancedPrompt = `${prompt}\n\nPlease provide three relevant website links related to the topic.`;

        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${geminiApiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [
                    {
                        parts: [
                            { text: enhancedPrompt }
                        ]
                    }
                ]
            })
        });

        const data = await response.json();
        const generatedContent = data.candidates[0]?.content.parts[0]?.text || '';

        const extractUrls = (content) => {
            const urlRegex = /(https?:\/\/[^\s]+)/g;
            const matches = content.match(urlRegex);
            return matches ? matches.slice(0, 3) : [];
        };

        const websites = extractUrls(generatedContent);

        analytics.submitted += 1;
        if (websites.length > 0) {
            analytics.successful += 1;
            res.json({ links: websites });
        } else {
            analytics.errors += 1;
            res.json({ message: 'No links found in the response.' });
        }
    } catch (error) {
        console.error('Error fetching response:', error.message);
        analytics.errors += 1;
        res.status(500).json({ message: 'Error fetching response.', error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
